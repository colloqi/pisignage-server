#!/bin/bash

echo "Installing PiSignage"
echo "..................First get the release zip file Manually ....................."
echo "wget http://pisignage.com/releases/pi-image.zip"
echo "unzip pi-image.zip"
echo "mv piImage piSignagePro"
echo "rm pi-image.zip"

echo "Adding pisignage auto startup"
echo "resize the SD card will happen on next reboot"
cd ~
sudo apt-get -y install build-essential autoconf liblockdev1-dev libudev-dev git libtool pkg-config


cp ~/piSignagePro/misc/start.sh ~/
cp ~/piSignagePro/misc/omx.py ~/

echo "Adding network-config file to /usr/bin"
sudo cp ~/piSignagePro/misc/network-config /usr/bin
sudo chmod +x  /usr/bin/network-config

sudo mv /etc/xdg/lxsession/LXDE/autostart /etc/xdg/lxsession/LXDE/autostart.bak
sudo cp ~/piSignagePro/misc/autostart /etc/xdg/lxsession/LXDE/


echo "Making modifications to X..."
#[ -f ~/.gtkrc-2.0 ] && rm -f ~/.gtkrc-2.0
# Do we need this ????
#ln -s ~/piSignagePro/misc/gtkrc-2.0 ~/.gtkrc-2.0

[ -f ~/.config/openbox/lxde-rc.xml ] && mv ~/.config/openbox/lxde-rc.xml ~/.config/openbox/lxde-rc.xml.bak
[ -d ~/.config/openbox ] || mkdir -p ~/.config/openbox
ln -s ~/piSignagePro/misc/lxde-rc.xml ~/.config/openbox/lxde-rc.xml
[ -f ~/.config/lxpanel/LXDE/panels/panel ] && mv ~/.config/lxpanel/LXDE/panels/panel ~/.config/lxpanel/LXDE/panels/panel.bak
sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf

# Let monitor be on Always
sudo sed -e 's/^BLANK_TIME=.*/BLANK_TIME=0/g' -i /etc/kbd/config
sudo sed -e 's/^POWERDOWN_TIME=.*/POWERDOWN_TIME=0/g' -i /etc/kbd/config

#echo "Enabling Watchdog..."
#sudo cp /etc/modules /etc/modules.bak
#sudo sed '$ i\bcm2708_wdog' -i /etc/modules
#sudo chkconfig watchdog on
#sudo cp /etc/watchdog.conf /etc/watchdog.conf.bak
#sudo sed -e 's/#watchdog-device/watchdog-device/g' -i /etc/watchdog.conf
#sudo /etc/init.d/watchdog start



echo "configure piSignage"
#git clone git://github.com/colloqi/piSignage.git ~/piSignage
cd ~/piSignagePro
npm install

chmod +x misc/upgrade.sh
chmod +x misc/downgrade.sh

#create ~/.bash_profile file
[ -f ~/.bash_profile ] && mv ~/.bash_profile ~/.bash_profile.bak
sudo cp ~/piSignagePro/misc/bash_profile ~/.bash_profile
echo ". ~/.bash_profile" >> ~/.bashrc

echo "Enable Usb tethering"
sudo cp /etc/network/interfaces  /etc/network/interfaces.bak
sudo cp ~/piSignagePro/misc/interfaces /etc/network/interfaces

echo " Raspbian Libcec: removed compilation: just install complied lib and bin"
#git clone git://github.com/Pulse-Eight/libcec.git
#cd libcec
#./bootstrap
#./configure --with-rpi-include-path=/opt/vc/include --with-rpi-lib-path=/opt/vc/lib --enable-rpi
#make
#sudo make install
#rm -R libcec

#cd /usr/local/lib
#sudo chmod 755 /usr/local/lib
#sudo cp ~/piSignagePro/cec/libcec.*  /usr/local/lib
#sudo cp ~/piSignagePro/cec/cec*  /usr/local/bin
#
#sudo ln -s libcec.so.2.0.1 libcec.so.2
#sudo ln -s libcec.so.2.0.1  libcec.so
#
#sudo ldconfig

#sudo chmod +x /usr/local/bin/cec-client
 
#cec-client -l
#force to HDMI
#echo "as" | cec-client -s

#on the TV
#echo "on 0" | cec-client -s
#Off
#echo 'standby 0' | cec-client -s
#cec-client -s for monitoring

#echo h | cec-client -s -d 1

#Power status
#echo pow 0 | cec-client -d 1 -s


#allow-hotplug wlan0
#iface wlan0 inet manual
#wpa-roam /etc/wpa_supplicant/wpa_supplicant.conf
#iface default inet dhcp

echo "Quiet the boot process..."
sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
sudo cp ~/piSignagePro/misc/cmdline.txt /boot/cmdline.txt
#sudo sed 's/$/ quiet/' -i /boot/cmdline.txt

#echo "Install btsync on pi"
#echo "download the btsync_arm.tar.gz from http://www.bittorrent.com/sync/downloads"
#echo "scp btsync_arm.tar.gz pi@yourpiip:/home/pi

#cp ~/piSignagePro/btsync/bin/btsync_rpi.tar.gz ~/
#tar -xvzf btsync_rpi.tar.gz
#tar -xvzf ~/piSignagePro/btsync/bin/btsync_rpi.tar.gz -C ~/piSignagePro/btsync/bin/
#sudo cp /home/pi/btsync   /usr/bin/

cp ~/piSignagePro/piupdate.png ~/
sudo cp ~/piSignagePro/misc/newwelcome /etc/init.d/
sudo chmod a+x /etc/init.d/newwelcome
sudo insserv /etc/init.d/newwelcome


#sudo sh /home/pi/piSignagePro/misc/rpi-wiggle


#enable fsck on boot.
# /dev/mmcblk0p2  /       ext4    remount,rw,defaults,noatime        0       1
sudo cp -f  ~/piSignagePro/misc/pifstab /etc/fstab
sudo sed -i 's/.*#FSCKFIX.*/FSCKFIX=yes/' /etc/default/rcS

# include rc.local to force fsck 
sudo mv /etc/rc.local /etc/rc.local.old
sudo mv ~/piSignagePro/misc/rc.local /etc/
sudo chmod 755 /etc/rc.local

cd ~
wget  https://dl.dropboxusercontent.com/u/166564018/brand_pisignage.mp4

printf "p" |sudo fdisk /dev/mmcblk0
echo "****************************"
echo " copy the end block number for /dev/mmcblk0p2"
echo " Remove the sdcard and create release image on Linux or Mac m/c typical 5785600"
echo " Use this end block number as count while cloning image pisignagepro"
echo " command to be used: sudo dd if=/dev/rdisk1 of=~/Desktop/pisignagepro.img bs=512 count=5785600 endblock no +1"
echo " gzip pisignagepro.img and copy it to pisignage.com /data/platformrelease folder."


read -p "Shutdown and create clone image (y/n)?"
[ "$REPLY" != "y" ] || sudo shutdown -h now
