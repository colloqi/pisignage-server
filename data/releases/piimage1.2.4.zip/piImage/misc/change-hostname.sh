#!/bin/sh
##########################################################################################
###  Run this script as a super user , Like sudo sh change.sh method newaddress newname
##   "method"
##	   'change' for changing parameters, 'revert' for revert to statndard parameters
##   "newaddress"
##	    new address name to be saved in /etc/dhcp/dhclient.conf
##   "newname"
##	    new name to be saved in /etc/hostname and /etc/hosts
##########################################################################################

DHCLIENT="/etc/dhcp/dhclient.conf"
HOSTS="/etc/hosts"
HOSTNAME="/etc/hostname"
newname=$1

echo "changing name "
sed -i "s/.*send host-name \".*/send host-name \"$newname\";/" $DHCLIENT
sed -i "s/^send host-name =.*/#send host-name = gethostname();/" $DHCLIENT
sed -i "s/.*127.0.1.1.*/127.0.1.1	$newname/" $HOSTS
echo "$newname" > $HOSTNAME





