#!/usr/bin/env bash
# PI_VERSION='ps2'
# VERSION=`cat /etc/debian_version`
# TODAY=`date +"%F"`
# PACKAGE_JSON=/home/pi/piSignagePro/package.json
# VERSION_NAME=${PI_VERSION}_${VERSION}_${TODAY}

# if grep -q platform_version $PACKAGE_JSON;then
#         echo "line present"
#         sed -i 's/.*platform_version.*/    "platform_version":  "'$VERSION_NAME'",/' $PACKAGE_JSON
# else
#         echo "line not present"
#         sed -i '/.*version.*/a \    "platform_version":  "'$VERSION_NAME'", ' $PACKAGE_JSON
# fi


echo "Adding network-config file to /usr/bin"
sudo rm -rf  /usr/bin/network-config

sudo cp /home/pi/piSignagePro/misc/network-config /usr/bin
sudo chmod +x  /usr/bin/network-config
