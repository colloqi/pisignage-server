#!/usr/bin/python
import sys
import subprocess
import os
if os.path.exists('/home/pi/media/brand_intro.mp4'):
        path ='/home/pi/media/brand_intro.mp4'
else:
        path ='/home/pi/brand_pisignage.mp4'
a = subprocess.call( [ "omxplayer", "-o", "hdmi", path])