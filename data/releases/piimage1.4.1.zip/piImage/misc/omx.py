#!/usr/bin/python
import sys
import subprocess
import os

lines = open('/boot/config.txt')

for line in lines:
    if 'framebuffer_width' in line:
            width = line.strip("framebuffer_width=")
    if 'framebuffer_height' in line:
            height = line.strip("framebuffer_height=")

if os.path.exists('/home/pi/media/brand_intro.mp4'):
        path ='/home/pi/media/brand_intro.mp4'
else:
        path ='/home/pi/brand_pisignage.mp4'
a = subprocess.call( [ "omxplayer","--win","0 0 "+width+" "+height, "-o", "hdmi", path])