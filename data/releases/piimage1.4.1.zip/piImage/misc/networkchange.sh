#!/bin/bash
# this file is linked to factory reset
# change dns nameserver

change_dns(){
	echo "$1 $2"
	sudo mv  /etc/resolv.conf  /etc/resolv.conf.bak
	echo -e "nameserver $1 \nnameserver $2" >> /home/pi/resolv.conf
	sudo mv /home/pi/resolv.conf /etc/resolv.conf
}

change_dns $1 $2