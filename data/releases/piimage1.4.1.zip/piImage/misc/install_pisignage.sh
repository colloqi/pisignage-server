#!/bin/bash
# This script will be called by install.sh

notify(){
    printf "\n"
    figlet -f digital -c $1
    printf "\n"
}

wheezySetup(){
    notify "startup script"
    cp /home/pi/piSignagePro/misc/wheezy/start.sh /home/pi/
    sed -i '/sudo raspi-config --expand-rootfs/s/^/#/' /home/pi/start.sh
    cp /home/pi/piSignagePro/misc/omx.py /home/pi

    notify "modify X"
    [ -f /home/pi/.config/openbox/lxde-rc.xml ] && mv /home/pi/.config/openbox/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml.bak
    [ -d /home/pi/.config/openbox ] || mkdir -p /home/pi/.config/openbox
    ln -s /home/pi/piSignagePro/misc/wheezy/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml
    [ -f /home/pi/.config/lxpanel/LXDE/panels/panel ] && mv /home/pi/.config/lxpanel/LXDE/panels/panel /home/pi/.config/lxpanel/LXDE/panels/panel.bak
    sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf

    notify "quiet boot"
    sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
    sudo cp /home/pi/piSignagePro/misc/wheezy/cmdline.txt /boot/cmdline.txt

    notify "Welcome video"
    sudo cp /home/pi/piSignagePro/misc/wheezy/newwelcome /etc/init.d/
    sudo chmod a+x /etc/init.d/newwelcome
    sudo insserv /etc/init.d/newwelcome

    #create ~/.bash_profile file
    [ -f /home/pi/.bash_profile ] && mv /home/pi/.bash_profile /home/pi/.bash_profile.bak
    sudo cp /home/pi/piSignagePro/misc/wheezy/bash_profile /home/pi/.bash_profile
    echo ". ~/.bash_profile" >> /home/pi/.bashrc

    #enable fsck on boot.
    # /dev/mmcblk0p2  /       ext4    remount,rw,defaults,noatime        0       1
    sudo cp -f  /home/pi/piSignagePro/misc/wheezy/pifstab /etc/fstab
    #sudo sed -i 's/.*#FSCKFIX.*/FSCKFIX=yes/' /etc/default/rcS

    # include rc.local to force fsck
    sudo mv /etc/rc.local /etc/rc.local.old
    sudo mv /home/pi/piSignagePro/misc/wheezy/rc.local /etc/
    sudo chmod 755 /etc/rc.local

	# version name will of the form :    ps2_7.8_user_2015-05-21
	echo "writing version number to package.json"
	PI_VERSION='ps2'
	VERSION=`cat /etc/debian_version`
	TODAY=`date +"%F"`
	ME='user'
	PACKAGE_JSON=/home/pi/piSignagePro/package.json
	VERSION_NAME=${PI_VERSION}_${VERSION}_${ME}_${TODAY}

    if grep -q platform_version $PACKAGE_JSON;then
        echo "line present"
        sed -i 's/.*platform_version.*/    "platform_version":  "'$VERSION_NAME'",/' $PACKAGE_JSON
    else
        echo "line not present"
        sed -i '/.*version.*/a \    "platform_version":  "'$VERSION_NAME'", ' $PACKAGE_JSON
    fi

    sudo rpi-update
}

jessieSetup(){
	notify "Auto startup script"
	cp /home/pi/piSignagePro/misc/jessie/start.sh /home/pi/
	sed -i '/sudo raspi-config --expand-rootfs/s/^/#/' /home/pi/start.sh
	cp /home/pi/piSignagePro/misc/omx.py /home/pi

    notify "modify X"
    [ -f /home/pi/.config/openbox/lxde-rc.xml ] && mv /home/pi/.config/openbox/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml.bak
    [ -d /home/pi/.config/openbox ] || mkdir -p /home/pi/.config/openbox
    ln -s /home/pi/piSignagePro/misc/jessie/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml
    [ -f /home/pi/.config/lxpanel/LXDE/panels/panel ] && mv /home/pi/.config/lxpanel/LXDE/panels/panel /home/pi/panel.bak
    #sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf
    sudo cp /home/pi/piSignagePro/misc/jessie/lightdm.conf /etc/lightdm/lightdm.conf

    #jessie screen ON option
    sudo sed -e 's/^BLANK_DPMS=.*/BLANK_DPMS=off/g' -i /etc/kbd/config

    # jessie swap size
    sudo sed -i 's/.*CONF_SWAPSIZE=.*/CONF_SWAPSIZE=500/' /etc/dphys-swapfile

    notify "Quiet boot"
    sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
    sudo cp /home/pi/piSignagePro/misc/jessie/cmdline.txt /boot/cmdline.txt

    #copy unit file and restart daemon
    notify "Welcome Video"
    sudo cp /home/pi/piSignagePro/misc/jessie/welcome.service /etc/systemd/system
    sudo systemctl daemon-reload
    sudo systemctl enable welcome.service

    [ -f /home/pi/.bash_profile ] && mv /home/pi/.bash_profile /home/pi/.bash_profile.bak
    sudo cp /home/pi/piSignagePro/misc/jessie/bash_profile /home/pi/.bash_profile
    echo ". ~/.bash_profile" >> /home/pi/.bashrc

	# version name will of the form :    ps2_7.8_user_2015-05-21
	echo "writing version number to package.json"
	PI_VERSION='ps3'
	VERSION=`cat /etc/debian_version`
	TODAY=`date +"%F"`
	ME='user'
	PACKAGE_JSON=/home/pi/piSignagePro/package.json
	VERSION_NAME=${PI_VERSION}_${VERSION}_${ME}_${TODAY}

    if grep -q platform_version $PACKAGE_JSON;then
        echo "line present"
        sed -i 's/.*platform_version.*/    "platform_version":  "'$VERSION_NAME'",/' $PACKAGE_JSON
    else
        echo "line not present"
        sed -i '/.*version.*/a \    "platform_version":  "'$VERSION_NAME'", ' $PACKAGE_JSON
    fi
}

install_nodejs(){
    notify "nodejs 10.28 and npm "
    wget -cN http://nodejs.org/dist/v0.10.28/node-v0.10.28-linux-arm-pi.tar.gz
    tar -xvzf node-v0.10.28-linux-arm-pi.tar.gz
    sudo mkdir /opt/node
    sudo cp -R node-v0.10.28-linux-arm-pi/* /opt/node
    rm -r node-v0.10.28-linux-arm-pi
    sudo ln -s /opt/node/bin/node /usr/bin/node
    sudo ln -s /opt/node/lib/node /usr/lib/node
    sudo ln -s /opt/node/bin/npm /usr/bin/npm

    get_npm_modules
}

get_npm_modules(){
    cd /home/pi/piSignagePro
    npm cache clean
    npm install
    echo "adding line in socket.io npm"
    sed "s/.*self\.transport\.onClose.*/if \(self\.transport\) self\.transport\.onClose\(\)/" -i ~/piSignagePro/node_modules/socket.io-client/lib/socket.js
}

export LC_ALL=C
export LANG=en_US.UTF-8

sudo apt-get -y remove --purge wolfram* zenity*
sudo apt-get -y remove --purge scratch dillo galculator sonic-pi netsurf-gtk
sudo apt-get -y remove --purge man-db leafpad gpicview xpdf qdbus manpages-dev

notify "dependencies"
sudo apt-get -y install  omxplayer x11-xserver-utils chkconfig unclutter liblockdev1-dev read-edid watchdog fbi host ethtool nmap  cec-utils

notify "livestreamer"
sudo apt-get -y install python-pip
sudo pip install livestreamer   #does not work with pip-3.2
sudo apt-get -y autoremove      #removes packages which are no longer needed after install of other packages
sudo rm -rf /var/cache/apt/archives/*
rm -rf /home/pi/python_games

notify "get update"
sudo apt-get  update
sudo apt-get -y upgrade

notify "webkit 3.0"
sudo apt-get -y install libwebkitgtk-3.0-dev

notify "install uzbl"
cd /home/pi/
git clone git://github.com/uzbl/uzbl.git
cd uzbl
git checkout 35db169a31c8c02b1846828c60ced8454b819a9c
make
sudo make install
sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl

sudo apt-get -y install python3-pip
sudo pip-3.2 install six

echo "Adding network-config file to /usr/bin"
sudo cp /home/pi/piSignagePro/misc/network-config /usr/bin
sudo chmod +x  /usr/bin/network-config

notify "lxde settings"
sudo mv /etc/xdg/lxsession/LXDE/autostart /etc/xdg/lxsession/LXDE/autostart.bak
sudo cp /home/pi/piSignagePro/misc/autostart /etc/xdg/lxsession/LXDE/

notify "keep monitor ON"
sudo sed -e 's/^BLANK_TIME=.*/BLANK_TIME=0/g' -i /etc/kbd/config
sudo sed -e 's/^POWERDOWN_TIME=.*/POWERDOWN_TIME=0/g' -i /etc/kbd/config

# Make sure we have 32bit framebuffer depth; but alpha needs to go off due to bug.
if grep -q framebuffer_depth /boot/config.txt; then
  sudo sed 's/^framebuffer_depth.*/framebuffer_depth=32/' -i /boot/config.txt
else
  echo 'framebuffer_depth=32' | sudo tee -a /boot/config.txt > /dev/null
fi

# Fix frame buffer bug
if grep -q framebuffer_ignore_alpha /boot/config.txt; then
  sudo sed 's/^framebuffer_ignore_alpha.*/framebuffer_ignore_alpha=1/' -i /boot/config.txt
else
      echo 'framebuffer_ignore_alpha=1' | sudo tee -a /boot/config.txt > /dev/null
fi

# enable overscan to take care of HD ready 720p, older TVs
sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_mode.*/hdmi_mode=4/' -i /boot/config.txt
sudo sed 's/.*hdmi_drive.*/hdmi_drive=2/' -i /boot/config.txt
sudo sed -i '$a\overscan_scale=1' /boot/config.txt
sudo sed -i '/sdtv_mode/ a\sdtv_aspect=3' /boot/config.txt

sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

if grep -q display_rotate  /boot/config.txt; then
  echo "line already present"
else
  echo 'display_rotate=0' | sudo tee -a /boot/config.txt > /dev/null
fi

# set gpu mem to depending upon RAM
echo 'gpu_mem_512=128' | sudo tee -a /boot/config.txt > /dev/null
echo 'gpu_mem_1024=256' | sudo tee -a /boot/config.txt > /dev/null

echo "configure piSignage"
chmod +x /home/pi/piSignagePro/misc/upgrade.sh
chmod +x /home/pi/piSignagePro/misc/downgrade.sh

notify "enable usb tethering"
sudo cp /etc/network/interfaces  /etc/network/interfaces.bak
sudo cp /home/pi/piSignagePro/misc/interfaces /etc/network/interfaces

notify "create directory for piSignage"
mkdir -p /home/pi/media
chmod -R 777 /home/pi/media

mkdir -p /home/pi/logs
chmod -R 777 /home/pi/logs

cp /home/pi/piSignagePro/piupdate.png /home/pi/

notify "welcome video"
cd /home/pi/
wget -cN https://s3.amazonaws.com/pisignage/assets/brand_pisignage.mp4

NODEEXIST=`which nodejs`
if grep -q "jessie" /etc/*-release ;
then
    # code if found
    notify "jessie"
    if [ ! "$NODEEXIST" ];then
        echo "nodejs not present"
        install_nodejs
    else
        echo "nodejs already present"
        sudo apt-get -y remove nodejs
        install_nodejs
    fi
    jessieSetup
else
    # code if not found
    notify "wheezy"
    install_nodejs
    wheezySetup
fi

sudo apt-get -y autoremove

read -p "Installation complete ,  Reboot The System  [y/n] : "  REPLY
[ "$REPLY" != "y" ] || sudo reboot

