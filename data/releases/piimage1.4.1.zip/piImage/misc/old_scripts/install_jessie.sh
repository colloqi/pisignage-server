PI_VERSION='ps2'

echo "Installing PiSignage"

echo "Updating/Upgrading system packages"
sudo apt-get -y remove --purge wolfram* zenity*
sudo apt-get -y remove --purge  scratch dillo galculator sonic-pi netsurf-gtk
sudo apt-get -y remove --purge nano man-db leafpad gpicview xpdf qdbus manpages-dev
sudo apt-get -y install python-pip
sudo pip install livestreamer
sudo rm -rf /var/cache/apt/archives/*
rm -rf /home/pi/python_games
sudo apt-get  update
sudo apt-get -y upgrade

sudo apt-get -y install  omxplayer x11-xserver-utils chkconfig unclutter liblockdev1-dev read-edid watchdog fbi host ethtool nmap  cec-utils
sudo apt-get -y install libwebkitgtk-3.0-dev

cd /home/pi/
echo "Installing uzbl..."
git clone git://github.com/uzbl/uzbl.git
cd uzbl
git checkout 35db169a31c8c02b1846828c60ced8454b819a9c
make
sudo make install
sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl

sudo apt-get -y install python3-pip
sudo pip-3.2 install six

echo "Adding pisignage auto startup"
cp /home/pi/piSignagePro/misc/jessie/start.sh /home/pi/

echo "Adding network-config file to /usr/bin"
sudo cp /home/pi/piSignagePro/misc/network-config /usr/bin
sudo chmod +x  /usr/bin/network-config

echo "changing lxde settings"
sudo mv /etc/xdg/lxsession/LXDE/autostart /etc/xdg/lxsession/LXDE/autostart.bak
sudo cp /home/pi/piSignagePro/misc/autostart /etc/xdg/lxsession/LXDE/

echo "Making modifications to X..."
[ -f /home/pi/.config/openbox/lxde-pi-rc.xml ] && mv /home/pi/.config/openbox/lxde-pi-rc.xml /home/pi/.config/openbox/lxde-pi-rc.xml.bak
ln -s /home/pi/piSignagePro/misc/jessie/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml
[ -f /home/pi/.config/lxpanel/LXDE-pi/panels/panel ] && mv /home/pi/.config/lxpanel/LXDE-pi/panels/panel /home/pi/panel.bak
sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf

# Let monitor be on Always
sudo sed -e 's/^BLANK_TIME=.*/BLANK_TIME=0/g' -i /etc/kbd/config
sudo sed -e 's/^BLANK_DPMS=.*/BLANK_DPMS=off/g' -i /etc/kbd/config
sudo sed -e 's/^POWERDOWN_TIME=.*/POWERDOWN_TIME=0/g' -i /etc/kbd/config

# Make sure we have 32bit framebuffer depth; but alpha needs to go off due to bug.
if grep -q framebuffer_depth /boot/config.txt; then
  sudo sed 's/^framebuffer_depth.*/framebuffer_depth=32/' -i /boot/config.txt
else
  echo 'framebuffer_depth=32' | sudo tee -a /boot/config.txt > /dev/null
fi

# Fix frame buffer bug
if grep -q framebuffer_ignore_alpha /boot/config.txt; then
  sudo sed 's/^framebuffer_ignore_alpha.*/framebuffer_ignore_alpha=1/' -i /boot/config.txt
else
      echo 'framebuffer_ignore_alpha=1' | sudo tee -a /boot/config.txt > /dev/null
fi

# enable overscan to take care of HD ready 720p, older TVs
sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_mode.*/hdmi_mode=4/' -i /boot/config.txt
sudo sed 's/.*hdmi_drive.*/hdmi_drive=2/' -i /boot/config.txt
sudo sed -i '$a\overscan_scale=1' /boot/config.txt

sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

sudo sed -i 's/.*CONF_SWAPSIZE=.*/CONF_SWAPSIZE=500/' /etc/dphys-swapfile

if grep -q display_rotate  /boot/config.txt; then
  echo "line already present"
else
  echo 'display_rotate=0' | sudo tee -a /boot/config.txt > /dev/null
fi

# set gpu mem to depending upon RAM
echo 'gpu_mem_512=128' | sudo tee -a /boot/config.txt > /dev/null
echo 'gpu_mem_1024=256' | sudo tee -a /boot/config.txt > /dev/null

echo "Installing nodejs 10.28 and npm "
wget http://nodejs.org/dist/v0.10.28/node-v0.10.28-linux-arm-pi.tar.gz
tar -xvzf node-v0.10.28-linux-arm-pi.tar.gz
sudo mkdir /opt/node
sudo cp -R node-v0.10.28-linux-arm-pi/* /opt/node
rm -r node-v0.10.28-linux-arm-pi
sudo ln -s /opt/node/bin/node /usr/bin/node
sudo ln -s /opt/node/lib/node /usr/lib/node
sudo ln -s /opt/node/bin/npm /usr/bin/npm

cd /home/pi/piSignagePro
npm cache clean
npm install

echo "configure piSignage"
chmod +x misc/upgrade.sh
chmod +x misc/downgrade.sh

[ -f /home/pi/.bash_profile ] && mv /home/pi/.bash_profile /home/pi/.bash_profile.bak
sudo cp /home/pi/piSignagePro/misc/bash_profile /home/pi/.bash_profile
echo ". ~/.bash_profile" >> /home/pi/.bashrc

echo "Enable Usb tethering"
sudo cp /etc/network/interfaces  /etc/network/interfaces.bak
sudo cp /home/pi/piSignagePro/misc/interfaces /etc/network/interfaces

echo "Quiet the boot process..."
sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
sudo cp /home/pi/piSignagePro/misc/jessie/cmdline.txt /boot/cmdline.txt

echo "create directory for piSignage"
mkdir -p /home/pi/media
chmod -R 777 /home/pi/media

mkdir -p /home/pi/logs
chmod -R 777 /home/pi/logs

echo "writing version number to package.json"
# version name will of the form :    ps2_7.8_2015-05-21

VERSION=`cat /etc/debian_version`
TODAY=`date +"%F"`
PACKAGE_JSON=/home/pi/piSignagePro/package.json
VERSION_NAME=${PI_VERSION}_${VERSION}_${TODAY}

if grep -q platform_version $PACKAGE_JSON;then
    echo "line present"
    sed -i 's/.*platform_version.*/    "platform_version":  "'$VERSION_NAME'",/' $PACKAGE_JSON
else
    echo "line not present"
    sed -i '/.*version.*/a \    "platform_version":  "'$VERSION_NAME'", ' $PACKAGE_JSON
fi

cd /home/pi/
wget https://s3.amazonaws.com/pisignage/assets/brand_pisignage.mp4

printf " **************************************************************************** \n\n"
sudo fdisk -l
printf " **************************************************************************** \n\n"
echo " command to be used: sudo dd if=/dev/rdisk1 of=~/Desktop/pisignagepro.img bs=512 count=5785600 endblock no +1"

read -p "Installation complete , Shutdown To Take a Clone [y/n] : "  REPLY
[ "$REPLY" != "y" ] || sudo shutdown -h now