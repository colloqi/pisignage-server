#!/bin/bash
#midori -e Fullscreen -a www.bbc.co.uk &
#uzbl www.yahoo.com &
unclutter -idle 5 &
cd /home/pi/piSignagePro

sudo raspi-config --expand-rootfs
sed -i '7,9d' /home/pi/start.sh
sudo reboot

. /home/pi/.bash_profile
export WEBKIT_DISABLE_TBS=1
node pi-monitor.js

