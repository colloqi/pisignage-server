#!/usr/bin/env bash
CONFIG="/boot/config.txt"

echo "add sdtv support"
sudo sed -i 's/.*sdtv_mode.*/sdtv_mode=2/' $CONFIG
sudo sed -i '/sdtv_mode/ a\sdtv_aspect=3' $CONFIG