#!/bin/bash
notify (){
    printf "\n"
    figlet -f digital -c $1
    printf "\n"
}

build_Pisignage(){
    cd  /home/pi/piSignagePro/misc/
    . build_pisignage.sh 2>&1 | tee /home/pi/install.log
}

# find user OS and install the required version
install_Pisignage (){
    cd  /home/pi/piSignagePro/misc/
    . install_pisignage.sh 2>&1 | tee /home/pi/install.log
}

# get figlet
sudo apt-get install -y figlet

# make sapce for pisignage
echo "remove previous ones"
sudo rm /home/pi/pi-image.zip
sudo rm -rf piSignagePro
sudo rm -rf piImage

# get pisignage
cd /home/pi/
wget -cN http://pisignage.com/releases/pi-image.zip

if [ $? -eq 0 ]; then
    unzip pi-image.zip
    mv piImage piSignagePro

    notify "INSTALLING"
    notify "PISIGNAGE"

    # check action to be taken
    case $1 in
        "build") build_Pisignage
        ;;
        *) install_Pisignage
        ;;
    esac
else
    notify "FAIL to download piSignagePro"
fi
