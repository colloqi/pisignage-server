#!/bin/bash

echo "Installing PiSignage"


echo "Updating/Upgrading system packages"
sudo apt-get -y remove --purge wolfram* zenity*
sudo apt-get -y remove --purge midori scratch gdb  gcc dillo galculator sonic-pi wpagui pistore netsurf-gtk
sudo apt-get -y remove --purge  nano man-db leafpad gpicview xpdf weston qdbus manpages-dev
sudo apt-get -y install python-pip
sudo pip install livestreamer
sudo apt-get -y autoremove
sudo rm -rf /var/cache/apt/archives/*
rm -rf /home/pi/python_games
sudo apt-get  update
sudo apt-get -y upgrade


echo "Installing dependencies..."
sudo apt-get -y install   uzbl omxplayer x11-xserver-utils chkconfig unclutter liblockdev1-dev read-edid watchdog fbi host ethtool nmap  cec-utils

#echo "Increasing swap space to 500MB..."
#echo "CONF_SWAPSIZE=500" > ~/dphys-swapfile
#sudo cp /etc/dphys-swapfile /etc/dphys-swapfile.bak
#sudo mv ~/dphys-swapfile /etc/dphys-swapfile


echo "Adding pisignage auto startup"
###cp ~/piSignagePro/misc/start.sh ~/
###cp ~/piSignagePro/misc/omx.py ~/

###sudo mv /etc/xdg/lxsession/LXDE/autostart /etc/xdg/lxsession/LXDE/autostart.bak
###sudo cp ~/piSignagePro/misc/autostart /etc/xdg/lxsession/LXDE/


echo "Making modifications to X..."
#[ -f ~/.gtkrc-2.0 ] && rm -f ~/.gtkrc-2.0
# Do we need this ????
#ln -s ~/piSignagePro/misc/gtkrc-2.0 ~/.gtkrc-2.0

###[ -f ~/.config/openbox/lxde-rc.xml ] && mv ~/.config/openbox/lxde-rc.xml ~/.config/openbox/lxde-rc.xml.bak
###[ -d ~/.config/openbox ] || mkdir -p ~/.config/openbox
###ln -s ~/piSignagePro/misc/lxde-rc.xml ~/.config/openbox/lxde-rc.xml
###[ -f ~/.config/lxpanel/LXDE/panels/panel ] && mv ~/.config/lxpanel/LXDE/panels/panel ~/.config/lxpanel/LXDE/panels/panel.bak
###sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf

# Let monitor be on Always
###sudo sed -e 's/^BLANK_TIME=.*/BLANK_TIME=0/g' -i /etc/kbd/config
###sudo sed -e 's/^POWERDOWN_TIME=.*/POWERDOWN_TIME=0/g' -i /etc/kbd/config

#echo "Enabling Watchdog..."
#sudo cp /etc/modules /etc/modules.bak
#sudo sed '$ i\bcm2708_wdog' -i /etc/modules
#sudo chkconfig watchdog on
#sudo cp /etc/watchdog.conf /etc/watchdog.conf.bak
#sudo sed -e 's/#watchdog-device/watchdog-device/g' -i /etc/watchdog.conf
#sudo /etc/init.d/watchdog start


# Make sure we have 32bit framebuffer depth; but alpha needs to go off due to bug.
if grep -q framebuffer_depth /boot/config.txt; then
  sudo sed 's/^framebuffer_depth.*/framebuffer_depth=32/' -i /boot/config.txt
else
  echo 'framebuffer_depth=32' | sudo tee -a /boot/config.txt > /dev/null
fi

# Fix frame buffer bug
if grep -q framebuffer_ignore_alpha /boot/config.txt; then
  sudo sed 's/^framebuffer_ignore_alpha.*/framebuffer_ignore_alpha=1/' -i /boot/config.txt
else
      echo 'framebuffer_ignore_alpha=1' | sudo tee -a /boot/config.txt > /dev/null
fi

# enable overscan to take care of HD ready 720p, older TVs
sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
#sudo sed 's/.*overscan_left.*/overscan_left=4/' -i /boot/config.txt
#sudo sed 's/.*overscan_right.*/overscan_right=4/' -i /boot/config.txt
#sudo sed 's/.*overscan_top.*/overscan_top=4/' -i /boot/config.txt
#sudo sed 's/.*overscan_bottom.*/overscan_bottom=4/' -i /boot/config.txt
sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
# selecting CEA 720p at 60Hz convert videos and images to 1280x720 size
sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_mode.*/hdmi_mode=4/' -i /boot/config.txt
#force HDMI
sudo sed 's/.*hdmi_drive.*/hdmi_drive=2/' -i /boot/config.txt
sudo sed -i '$a\overscan_scale=1' /boot/config.txt

sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

if grep -q display_rotate  /boot/config.txt; then
  echo "line already present"
else
  echo 'display_rotate=0' | sudo tee -a /boot/config.txt > /dev/null
fi

# set gpu mem to 128MB
#if grep -q gpu_mem /boot/config.txt; then
#  sudo sed 's/^gpu_mem.*/gpu_mem=128/' -i /boot/config.txt
#else
echo 'gpu_mem_512=128' | sudo tee -a /boot/config.txt > /dev/null
echo 'gpu_mem_1024=256' | sudo tee -a /boot/config.txt > /dev/null

#fi


echo "Installing nodejs 10.28"
wget http://nodejs.org/dist/v0.10.28/node-v0.10.28-linux-arm-pi.tar.gz
tar -xvzf node-v0.10.28-linux-arm-pi.tar.gz
sudo mkdir /opt/node
sudo cp -R node-v0.10.28-linux-arm-pi/* /opt/node
rm -r node-v0.10.28-linux-arm-pi
sudo ln -s /opt/node/bin/node /usr/bin/node
sudo ln -s /opt/node/lib/node /usr/lib/node
sudo ln -s /opt/node/bin/npm /usr/bin/npm

echo "configure piSignage"
#git clone git://github.com/colloqi/piSignage.git ~/piSignage
###cd ~/piSignagePro
###npm install

###chmod +x misc/upgrade.sh
###chmod +x misc/downgrade.sh

#create ~/.bash_profile file
###[ -f /home/pi/.bash_profile ] && mv /home/pi/.bash_profile /home/pi/.bash_profile.bak
###sudo cp ~/piSignagePro/misc/bash_profile ~/.bash_profile
###echo ". ~/.bash_profile" >> ~/.bashrc

echo "Enable Usb tethering"
###sudo cp /etc/network/interfaces  /etc/network/interfaces.bak
###sudo cp ~/piSignagePro/misc/interfaces /etc/network/interfaces

echo " Raspbian Libcec: removed compilation: just install complied lib and bin"
#cd ~
#sudo apt-get -y install build-essential autoconf liblockdev1-dev libudev-dev git libtool pkg-config
#git clone git://github.com/Pulse-Eight/libcec.git
#cd libcec
#./bootstrap
#./configure --with-rpi-include-path=/opt/vc/include --with-rpi-lib-path=/opt/vc/lib --enable-rpi
#make
#sudo make install
#rm -R libcec

###cd /usr/local/lib
###sudo chmod 755 /usr/local/lib
###sudo cp ~/piSignagePro/cec/libcec.*  /usr/local/lib
###sudo cp ~/piSignagePro/cec/cec*  /usr/local/bin

###sudo ln -s libcec.so.2.0.1 libcec.so.2
###sudo ln -s libcec.so.2.0.1  libcec.so

###sudo ldconfig

###sudo chmod +x /usr/local/bin/cec-client
 
#cec-client -l
#force to HDMI
#echo "as" | cec-client -s

#on the TV
#echo "on 0" | cec-client -s
#Off
#echo 'standby 0' | cec-client -s
#cec-client -s for monitoring

#echo h | cec-client -s -d 1

#Power status
#echo pow 0 | cec-client -d 1 -s


#allow-hotplug wlan0
#iface wlan0 inet manual
#wpa-roam /etc/wpa_supplicant/wpa_supplicant.conf
#iface default inet dhcp

###echo "Quiet the boot process..."
###sudo cp /boot/cmdline.txt /boot/cmdline.txt.bak
###sudo cp ~/piSignagePro/misc/cmdline.txt /boot/cmdline.txt
#sudo sed 's/$/ quiet/' -i /boot/cmdline.txt

#echo "Install btsync on pi"
#echo "download the btsync_arm.tar.gz from http://www.bittorrent.com/sync/downloads"
#echo "scp btsync_arm.tar.gz pi@yourpiip:/home/pi

#cp ~/piSignagePro/btsync/bin/btsync_rpi.tar.gz ~/
#tar -xvzf btsync_rpi.tar.gz
#tar -xvzf ~/piSignagePro/btsync/bin/btsync_rpi.tar.gz -C ~/piSignagePro/btsync/bin/
#sudo cp /home/pi/btsync   /usr/bin/

mkdir -p /home/pi/media
chmod -R 777 /home/pi/media

#create a logs dir
mkdir -p /home/pi/logs
chmod -R 777 /home/pi/logs

#mkdir -p ~/.btsyncinfo

###cp ~/piSignagePro/piupdate.png ~/
###sudo cp ~/piSignagePro/misc/asplashscreen /etc/init.d/
###sudo chmod a+x /etc/init.d/asplashscreen
###sudo insserv /etc/init.d/asplashscreen


echo "Restart the Pi"
#cat /proc/cpuinfo |grep Serial|awk '{print $3 }'
#sudo curl -L --output $(which rpi-update) https://github.com/Hexxeh/rpi-update/raw/master/rpi-update
# latest version is causing problem setting HDMI mode to CEA 4. Hence working previous firmware.
#sudo rpi-update 74c1d00049db612f4c2a05d4a87d824cc9f21944
sudo rpi-update

#echo "resize the SD card"
#sudo sh /home/pi/piSignagePro/misc/rpi-wiggle



printf "p" |sudo fdisk /dev/mmcblk0
echo "****************************"
echo " copy the end block number for /dev/mmcblk0p2"
echo " Remove the sdcard and create release image on Linux or Mac m/c typical 5785600"
echo " Use this end block number as count while cloning image pisignagepro"
echo " command to be used: sudo dd if=/dev/rdisk1 of=~/Desktop/pisignagepro.img bs=512 count=5785600 endblock no +1"
echo " gzip pisignagepro.img and copy it to pisignage.com /data/platformrelease folder."


read -p "Shutdown and create clone image (y/n)?"
[ "$REPLY" != "y" ] || sudo shutdown -h now
