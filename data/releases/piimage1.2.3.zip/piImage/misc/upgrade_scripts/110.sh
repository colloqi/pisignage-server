#!/bin/sh
if grep -q display_rotate  /boot/config.txt; then
  echo "line already present"
else
  echo 'display_rotate=0' | sudo tee -a /boot/config.txt > /dev/null
fi
echo "Adding network-config file to /usr/bin"
sudo cp ~/piSignagePro/misc/network-config /usr/bin
sudo chmod +x  /usr/bin/network-config
#instal livestreamer
sudo apt-get -y install python-pip
sudo pip install livestreamer