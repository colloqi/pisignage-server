#!/bin/bash
#midori -e Fullscreen -a www.bbc.co.uk &
#uzbl www.yahoo.com &
unclutter -idle 5 &
cd ~/piSignagePro
#/opt/node/bin/node server.js
#forever start -l /var/log/forever.log -o /var/log/forever-out.log -e/var/log/forever-err.log server.js

#rpi-wiggle should be RUN ONLY ONCE
echo "CONF_SWAPSIZE=500" > ~/dphys-swapfile
sudo cp /etc/dphys-swapfile /etc/dphys-swapfile.bak
sudo mv ~/dphys-swapfile /etc/dphys-swapfile
sudo sh ~/piSignagePro/misc/rpi-wiggle
sed -i '9,14d' ~/start.sh
#forever start --append -l ~/forever.log pi-server.js
. ~/.bash_profile
export WEBKIT_DISABLE_TBS=1
node pi-monitor.js

