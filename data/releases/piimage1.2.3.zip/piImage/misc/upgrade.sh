#!/bin/sh
####################################################################
# this script will take care of new release and auto update (modules should be attached)
#first kill forever process
#remove the current folder
#get file from the link
#change ownership
#reboot
#####################################################################

cd ~

echo "check .problem directory"
if [ -d "/home/pi/piSignagePro.problem" ]; then
	echo "directory exist"
	sudo rm -rf  /home/pi/piSignagePro.problem
else
	echo "directory does not exist"
fi

echo "get the new server release file"
ping -c 3 www.pisignage.com
rm $2
wget $1  -O $2
if [ $? -ne 0 ]; then
	echo "wget could not get the release file" 1>&2
#	exit 1
    echo "Instead of exit, reboot"
    sudo reboot
    exit 1
fi

# kill forever process
sudo pkill -f forever
sudo pkill -f node
sudo pkill -f uzbl
sudo pkill -f omx
sudo fbi -T 1 ~/piupdate.png &

echo "saving the current image"
sudo rm -rf  ~/piSignagePro.prev
mv ~/piSignagePro ~/piSignagePro.prev

echo "unzipping the New pi image"
unzip $2
mv ~/piImage ~/piSignagePro

echo "copying configuration files"
cp ~/piSignagePro.prev/config/_config.json ~/piSignagePro/config
cp ~/piSignagePro.prev/config/_settings.json ~/piSignagePro/config

echo "copying the previous node modules"
cp -R ~/piSignagePro.prev/node_modules ~/piSignagePro

rm $2
cd ~/piSignagePro

chmod +x misc/upgrade.sh
chmod +x misc/downgrade.sh
chmod -R +x misc/upgrade_scripts

echo "installing npm packages"
npm install

file="pi-upgrade.js"
if [ -f "$file" ]
then
	node $file
fi

sync

rm ~/piSignagePro/misc/install.sh ~/piSignagePro/misc/autostart

sudo reboot
